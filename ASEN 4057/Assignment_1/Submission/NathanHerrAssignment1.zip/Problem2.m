%Problem 2
clearvars; clc; close all;
%calculate best-fit line for set of experimental data

%input test data
x = [-3 12.1 20 0 8 3.7 -5.6 .5 5.8 10];
y = [-11.06 58.95 109.73 3.15 44.83 21.29 -27.29 5.11 34.01 43.25];

%call function with test case
[m,b] = Prob2findfit(x,y);

%input wind tunnel data
alpha = [-5 -2 0 2 3 5 7 10 14];
cl = [-.008 -.003 .001 .005 .007 .006 .009 .017 .019];

%call function with wind tunnel data and find fit line
[m2,b2] = Prob2findfit(alpha, cl);

tunnelfit = m2*alpha + b2;

%plot data and best fit line
figure 
hold on
title('Angle of attack vs. Coefficient of Lift with line of best fit')
xlabel('Angle of attack')
ylabel('Coefficient of Lift')
plot(alpha, cl,'*')
plot(alpha, tunnelfit)
hold off
