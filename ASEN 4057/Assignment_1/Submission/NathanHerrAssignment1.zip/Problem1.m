%Problem 1
clearvars; clc; close all;
% calculate and plot plot horizontal and vertical displacements of a
% projectile given user inputs

%Get user inputs for launch angle and initial velocity
theta = input('Launch angle in degrees? \n');
V = input('Initial airspeed in m/s? \n');

%determine termination time
endtime = Prob1termtime(V,theta);

%create time vector for plotting
t = linspace(0,endtime);

%create x and y vectors
g = -9.81;% m/s^2
x = V*cosd(theta).*t;
y = .5*g*t.^2 + V*sind(theta).*t;

%plot displacements
%x
figure
hold on
title('Horizontal Position vs. time for Launch Angle of 45 degrees, Launch velocity of 50 m/s')
xlabel('time (s)')
ylabel('displacement (m)')
plot(t,x)
hold off

%y
figure
hold on
title('Vertical Position vs. time for Launch Angle of 45 degrees, Launch velocity of 50 m/s')
xlabel('time (s)')
ylabel('displacement (m)')
ylim([0 max(y)+20])
plot(t,y)
hold off


