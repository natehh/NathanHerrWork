function [ m,b ] = Prob2findfit( x,y )
%find best-fit line for a given set of data

% set N 
N = length(x);

%find A, B, C, and D values
A=0;
B=0;
C=0;
D=0;
for i=1:N
   A = A + x(i); 
   B = B + y(i);
   C = C + x(i)*y(i);
   D = D + x(i)^2;
end

%find m and b using given equations
m = (A*B-N*C)/(A^2-N*D);
b = (A*C-B*D)/(A^2-N*D);


end

