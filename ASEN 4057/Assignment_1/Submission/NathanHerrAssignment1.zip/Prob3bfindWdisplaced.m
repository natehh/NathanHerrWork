function [Wdisplaced] = Prob3bfindWdisplaced(r,h)
%define temperature and pressure using given piecewise function
if h>=0 && h<=11000
    T = 15.04-.00649*h;
    P = 101.29*((T+273.1)/288.08)^5.256;
end

if h>11000 && h<=25000
    T = -56.46;
    P = 22.65*exp(1.73-.000157*h);
end

if h>25000
    T = -131.21 + .00299*h;
    P = 2.488*((T+273.1)/216.6)^-11.388;
end

%density at a given altitude
rho = P/(.2869*(T+273.1));

%weight displaced by air
Wdisplaced = (4*pi*rho*r^3)/3;
end

