function [Wtot] = Prob3afindballoonWeight(r,Wpayload,Wballoon,MW)
%find total balloon weight using given equations
rho = 1.225; %kg/m^3
Wgas = (4*pi*rho*r^3)/3*(MW/28.966);
Wtot = Wgas + Wpayload + Wballoon;
end

