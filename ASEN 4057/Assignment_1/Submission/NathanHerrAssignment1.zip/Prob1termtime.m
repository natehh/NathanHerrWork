function [ endtime ] = Prob1termtime( V,theta )
%determine the termination time of the projectile flight
%initialize variables
t = 0;
y = 0;
g = -9.81; %m/s^2

%write loop to determine termination time
while y>=0
   y = .5*g*t^2 + V*sind(theta)*t;
   t = t+.001;
end
endtime = t;

end

