function [hmax] = Prob3cfindhmax(r,Wpayload, Wempty,MW)
%find maximum altitude

%find total weight and weight of displaced air for h=0
h = 0;
Wtot = Prob3afindballoonWeight(r,Wpayload, Wempty, MW);
Wdisplaced = Prob3bfindWdisplaced(r,h);

%use while loop to find max altitude
while Wtot<Wdisplaced
    Wtot = Prob3afindballoonWeight(r,Wpayload, Wempty, MW);
    Wdisplaced = Prob3bfindWdisplaced(r,h);
    h=h+10;
end
hmax = h;
end

