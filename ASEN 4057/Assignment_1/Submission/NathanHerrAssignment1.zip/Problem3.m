%Problem 3 
clearvars; clc; close all;
%solve provided problems using developed function
r = 3;%m
Wpayload = 5; %kg
Wempty = .6; %kg
MW = 4.02;
hmax = Prob3cfindhmax(r,Wpayload,Wempty,MW);
fprintf('The maximum altitude the balloon can reach is %6.1d m, to the nearest 10m\n',hmax)